# My Business Assistant

A chatbot front-end that answers from a list of questions and answers. No API, no backend, no build step.

## Files

- `index.html` - the page
- `style.css` - the look (light and dark mode)
- `knowledge.js` - the bot name, greeting, fallback message, and all questions and answers
- `script.js` - the matching logic and chat interface

## Run it locally

Open `index.html` in a browser.

## Put it on GitHub Pages

1. On GitHub, create a new repository (public).
2. Click **Add file > Upload files**, drag in all five files, and commit.
3. Go to **Settings > Pages**. Under **Build and deployment**, choose **Deploy from a branch**, pick `main` and `/ (root)`, then Save.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/YOUR-REPO/`.

## Change the answers

Edit `knowledge.js`. Each entry looks like this:

```js
{ q: ["Ways to ask it", "Another way"], a: "The answer.", k: ["extra", "keywords"], chip: true }
```

- `q` - different ways someone might ask the question
- `a` - the answer
- `k` - optional extra keywords that should also trigger this answer
- `chip: true` - optional, shows the question as a tap-to-ask suggestion button

Commit the change on GitHub and the live site updates.
